﻿using AutoFramework.SetUp;
using AventStack.ExtentReports;
using AventStack.ExtentReports.MarkupUtils;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Extensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using WDSE;
using WDSE.Decorators;
using WDSE.ScreenshotMaker;

namespace AutoFramework.HelperClasses
{
    public static class ReportHelper
    {
        public static ExtentTest parentLog = HtmlReport.GetParentTestobj;
        public static ExtentTest childLog = HtmlReport.GetChildTestobj;
        public static ExtentTest testLog = HtmlReport.GetTestobj;
        public static ExtentReports extentreport = HtmlReport.extent;
        public static void CreateTest(string testname, string description)
        {
            parentLog = extentreport.CreateTest(testname, description).Info("<div style='color: black; font-size: 20px; font-weight: bold'>Test Execution Started!!!</div>");
        }
        public static void LogInfo(string description)
        {
            childLog.Log(Status.Info, MarkupHelper.CreateLabel(description, ExtentColor.Grey));
        }

        public static void PassTest(string description)
        {
            childLog.Pass(MarkupHelper.CreateLabel(description, ExtentColor.Green));
        }
        public static void FailTest(string description)
        {
            childLog.Fail(MarkupHelper.CreateLabel(description, ExtentColor.Red));
        }

        public static void TestError(Exception ex)
        {
            childLog.Error(MarkupHelper.CreateLabel("Exception occured!!" + ex.Message, ExtentColor.Red));
        }
        public static void TakeScreenshot(string screenshotname)
        {
            screenshotname = screenshotname + DateTime.Now.ToString("MM_dd_HH_mm_ss_mm");
            string screenshotpath = CaptureScreenshot(screenshotname);
            childLog.Info("Refer screenshot Here! - " + screenshotname, MediaEntityBuilder.CreateScreenCaptureFromPath(screenshotpath, screenshotname).Build());

        }
        public static void TakeFullPageScreenshot(string screenshotname)
        {
            //project path
            var path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            var actualPath = path.Substring(0, path.LastIndexOf("bin"));
            var projectPath = new Uri(actualPath).LocalPath;
            Directory.CreateDirectory(projectPath.ToString() + "Screenshots");
            screenshotname = screenshotname + DateTime.Now.ToString("MM_dd_HH_mm_ss_mm");
            var savePath = projectPath + "Screenshots\\" + screenshotname + ".png";
            //Take screenshot
            var vcs = new VerticalCombineDecorator(new ScreenshotMaker());
            Browsers.GetDriver.TakeScreenshot(vcs).ToMagickImage().ToBitmap().Save(savePath);
            childLog.Info("Refer screenshot Here! - " + screenshotname, MediaEntityBuilder.CreateScreenCaptureFromPath(savePath, screenshotname).Build());

        }
        public static string CaptureScreenshot(string name)
        {
            ITakesScreenshot ts = (ITakesScreenshot)Browsers.GetDriver;
            Screenshot shot = ts.GetScreenshot();
            var path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            var actualPath = path.Substring(0, path.LastIndexOf("bin"));
            var projectPath = new Uri(actualPath).LocalPath;
            Directory.CreateDirectory(projectPath.ToString() + "Screenshots");
            var savePath = projectPath + "Screenshots\\" + name + ".png";
            shot.SaveAsFile(savePath, ScreenshotImageFormat.Png);
            return savePath;
        }

        public static void FailTest(object fail)
        {
            throw new NotImplementedException();
        }

        public static void LogTest(Status status, string[][] data)
        {

            childLog.Log(status, MarkupHelper.CreateTable(data));
        }
        public static void CreateNode(string nodeName)
        {
            childLog = parentLog.CreateNode(nodeName);
        }

    }
}