﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.IO;
using ExcelDataReader;
using System.Data;

namespace AutoFramework.HelperClasses
{
    public static class ExcelHelper
    {
        public static string ExcelFilePath()
        {
            var path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            var actualPath = path.Substring(0, path.LastIndexOf("bin"));
            var projectPath = new Uri(actualPath).LocalPath;
            string excelpath = projectPath + "Excel\\FinalTestingData01.xlsx";
            return excelpath;
        }
        private static List<Datacollection> _dataCol;
        public static DataTableCollection tableCollection;
        public static string fileName = "";
        /// <summary>
        /// Storing all the excel values in to the in-memory collections
        /// </summary>
        /// <param name="fileName"></param>        
        public static void PopulateInCollection(string sheetName)
        {
            _dataCol = new List<Datacollection>();
            System.Data.DataTable table = tableCollection[sheetName];
            //Iterate through the rows and columns of the Table
            for (int row = 1; row <= table.Rows.Count; row++)
            {
                for (int col = 0; col < table.Columns.Count; col++)
                {
                    Datacollection dtTable = new Datacollection()
                    {
                        RowNumber = row,
                        ColName = table.Columns[col].ColumnName,
                        ColValue = table.Rows[row - 1][col].ToString(),
                        SheetName = sheetName
                    };
                    //Add all the details for each row
                    _dataCol.Add(dtTable);
                }
            }
        }

        /// <summary>
        /// Reading all the datas from Excelsheet
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static void ExcelToDataTable()
        {
            fileName = ExcelFilePath();
            //open file and returns as Stream
            FileStream stream = File.Open(fileName, FileMode.Open, FileAccess.Read);
            //Createopenxmlreader via ExcelReaderFactory
            IExcelDataReader excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream); //.xlsx
            var result = excelReader.AsDataSet(new ExcelDataSetConfiguration()
            {
                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                {
                    UseHeaderRow = true
                }
            });
            tableCollection = result.Tables;
        }
        public static string ReadData(int rowNumber, string columnName)
        {
            try
            {
                //Retriving Data using LINQ to reduce much of iterations
                string data = (from colData in _dataCol
                               where colData.ColName == columnName && colData.RowNumber == rowNumber
                               select colData.ColValue).FirstOrDefault();
                return data.ToString();
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public class Datacollection
        {
            public int RowNumber { get; set; }
            public string ColName { get; set; }
            public string ColValue { get; set; }
            public string SheetName { get; set; }
        }
        public static int GetRowCount(string sheetName)
        {
            System.Data.DataTable table = tableCollection[sheetName];
            int rowcount = table.Rows.Count;
            return rowcount;
        }

    }
}
