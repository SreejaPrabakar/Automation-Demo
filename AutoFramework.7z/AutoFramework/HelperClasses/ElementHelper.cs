﻿using AutoFramework.SetUp;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;

namespace AutoFramework.HelperClasses
{
    public static class ElementHelper
    {
        static Random rnd = new Random();
        static WebDriverWait wait = new WebDriverWait(Browsers.GetDriver, TimeSpan.FromSeconds(10));

        public static void EnterText(this IWebElement element, string text)
        {
            if (!String.IsNullOrEmpty(text))
            {
                element.SendKeys(text);
            }

        }

        public static void ClickOnIt(this IWebElement element)
        {
            element.Click();
        }
        public static void SelectByIndex(this IWebElement element, int index)
        {
            SelectElement s = new SelectElement(element);
            s.SelectByIndex(index);
        }
        public static void SelectRandom(this IWebElement element)
        {
            SelectElement s = new SelectElement(element);
            int itemCount = s.Options.Count();
            s.SelectByIndex(rnd.Next(1, itemCount));

        }
        public static void Multiple_Select(this IWebElement element)
        {
            SelectElement sel = new SelectElement(element);
            int Cnt = sel.Options.Count();
            for (int i = 1; i <= 5; i++)
            {
                sel.SelectByIndex(i);
            }
        }
        public static void SelectByText(this IWebElement element, string text)
        {
            SelectElement sel = new SelectElement(element);
            sel.SelectByText(text);

        }
        public static void SelectRandom_startwith0(this IWebElement element)
        {
            SelectElement s = new SelectElement(element);
            int itemCount = s.Options.Count();
            s.SelectByIndex(rnd.Next(0, itemCount));

        }
        public static string GetSelectedValue(this IWebElement element)
        {
            SelectElement s = new SelectElement(element);
            return s.AllSelectedOptions[0].Text;
        }
        public static void Hover(this IWebElement element)
        {
            Actions actions = new Actions(Browsers.GetDriver);
            actions.MoveToElement(element).Perform();
        }
        public static bool IsElementPresent(this IWebElement element)
        {
            try
            {
                bool ele = element.Displayed;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static string[] SplitString(string names)
        {
            return names.Split(';');
        }

        public static bool CompareLists(this IWebElement element, List<string> options)
        {
            List<string> values = new List<string>();
            foreach (string value in element.Text.Split('\r', '\n'))
            {
                if (value != "" && value != " ")
                {
                    values.Add(value.Trim());
                }
            }
            if (values.SequenceEqual(options))
                return true;
            else
                return false;

        }

        //To generate random string
        public static string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }
        //Wait Functions
        public static void WaitById(string id)
        {
            wait.Until(ExpectedConditions.ElementToBeClickable(By.Id(id)));
        }
        public static void WaitByXPath(string xpath)
        {
            wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(xpath)));
        }
        public static void ThreadWait(int time)
        {
            Thread.Sleep(time);

        }
    }
}