﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoFramework.SetUp
{
    [TestFixture]
    public class AutomationCore
    {
        [SetUp]
        public void startUpTest()// This method fire at the start of the Test
        {
            Browsers.Init();
            HtmlReport.Init();
        }

        [TearDown]
        public void endTest()// This method will fire at the end of the Test
        {
            HtmlReport.Close();
            Browsers.Close();
        }
    }
}