﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace AutoFramework.SetUp
{
    public class HtmlReport
    {
        public static ExtentReports extent;
        public static ExtentTest parentTest;
        public static ExtentTest childTest;
        public static ExtentTest test;
        public static DateTime date;
        public static void Init()
        {
            var path = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            var actualPath = path.Substring(0, path.LastIndexOf("bin"));
            var projectPath = new Uri(actualPath).LocalPath;
            Directory.CreateDirectory(projectPath.ToString() + "Reports");
            string fileName = "ExtentReport_" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss");
            var reportPath = projectPath + "Reports\\" + fileName + ".html";
            var htmlReporter = new ExtentHtmlReporter(reportPath);
            htmlReporter.LoadConfig(projectPath + "\\extent-config.xml");
            extent = new ExtentReports();
            extent.AttachReporter(htmlReporter);
            string hostname = Dns.GetHostName();
            string browser = System.Configuration.ConfigurationManager.AppSettings["browser"];
            extent.AddSystemInfo("Host Name", hostname);
            extent.AddSystemInfo("Environment", "DVV");
            extent.AddSystemInfo("Browser", browser);
            extent.AddSystemInfo("Username", "sreeja.p@hcl.com");
            CreateTest("<h2>Regression TESTCASES</h2>");
        }


        public static ExtentTest GetParentTestobj
        {
            get { return parentTest; }
        }
        public static ExtentTest GetChildTestobj
        {
            get { return childTest; }
        }
        public static ExtentTest GetTestobj
        {
            get { return test; }
        }
        public static ExtentReports GetReportobj
        {
            get { return extent; }
        }
        public static void CreateTest(string des)
        {
            parentTest = extent.CreateTest(TestContext.CurrentContext.Test.Name, des).Info("<div style='color: black; font-size: 20px; font-weight: bold'>Overall Test Execution Started!!!</div>");
        }
        public static void Close()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stacktrace = string.IsNullOrEmpty(TestContext.CurrentContext.Result.StackTrace)
                    ? "" : string.Format("{0}", TestContext.CurrentContext.Result.StackTrace);
            Status logstatus;

            switch (status)
            {
                case TestStatus.Failed:
                    logstatus = Status.Fail;
                    DateTime time = DateTime.Now;
                    break;
                default:
                    logstatus = Status.Pass;
                    break;
            }

            parentTest.Log(logstatus, "<div style='color: black; font-size: 20px; font-weight: bold'>Overall Test Ended with </div>" + logstatus + stacktrace);
            extent.Flush();
        }
    }
}
