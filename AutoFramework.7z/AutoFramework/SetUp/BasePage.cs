﻿using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoFramework.SetUp
{
    public abstract class BasePage
    {
        public static T GetPages<T>() where T : new()
        {
            var page = new T();
            PageFactory.InitElements(Browsers.GetDriver, page);
            return page;

        }
    }
}