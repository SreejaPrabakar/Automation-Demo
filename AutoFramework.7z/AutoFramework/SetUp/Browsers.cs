﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoFramework.SetUp
{
    public class Browsers
    {
        private static IWebDriver webDriver;
        private static string baseURL = System.Configuration.ConfigurationManager.AppSettings["url"];
        private static string browser = System.Configuration.ConfigurationManager.AppSettings["browser"];
        public static void Init()
        {
            switch (browser)
            {
                case "Chrome":
                    webDriver = new ChromeDriver();
                    break;
                case "IE":
                    var options = new InternetExplorerOptions();
                    options.EnableNativeEvents = false;
                    options.IgnoreZoomLevel = true;
                    options.EnablePersistentHover = true;
                    options.EnsureCleanSession = true;
                    webDriver = new InternetExplorerDriver(options);
                    break;
                case "Firefox":
                    webDriver = new FirefoxDriver();
                    break;
            }
            webDriver.Manage().Window.Maximize();
            //default wait time 3 seconds for not loading elements immediately
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3);
            ////default wait time for IE
            //webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(4);
            Goto(baseURL);
        }
        public static string Title
        {
            get { return webDriver.Title; }
        }
        public static IWebDriver GetDriver
        {
            get { return webDriver; }
        }
        public static void Goto(string url)
        {
            webDriver.Url = url;

        }
        public static void Close()
        {
            webDriver.Quit();
        }
    }
}
