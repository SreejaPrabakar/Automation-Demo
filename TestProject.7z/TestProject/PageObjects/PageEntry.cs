﻿using AutoFramework.SetUp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestProject.PageObjects
{
    public class PageEntry : BasePage
    {
        public static LoginPage Login
        {
            get { return GetPages<LoginPage>(); }
        }

        public static MyStorePage MyStore
        {
            get { return GetPages<MyStorePage>(); }
        }

        public static CreateAccountPage CreateAccount
        {
            get { return GetPages<CreateAccountPage>(); }
        }
    }
}