﻿using AutoFramework.HelperClasses;
using AutoFramework.SetUp;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestProject.PageObjects
{
    public class MyStorePage
    {
        public IWebDriver driver = Browsers.GetDriver;

        [FindsBy(How = How.XPath, Using = "//*[@id='header']/div[2]/div/div/nav/div[1]/a")]
        [CacheLookup]
        private IWebElement signInLink;
        [FindsBy(How = How.XPath, Using = "//*[@id='block_top_menu']/ul/li[2]/a")]
        [CacheLookup]
        private IWebElement dressesLink;
        [FindsBy(How = How.XPath, Using = "//*[@id='header']/div[3]/div/div/div[3]/div/a")]
        [CacheLookup]
        private IWebElement cartLink;
        [FindsBy(How = How.XPath, Using = "//*[@id='header']/div[2]/div/div/nav/div[2]/a")]
        [CacheLookup]
        private IWebElement signOutLink;
        //string to store element identifiers
        string cartPath = "//*[@id='header']/div[3]/div/div/div[3]/div/a";

        public void ClickSignIn()
        {
            signInLink.ClickOnIt();
        }
        public void ClickDresses()
        {
            dressesLink.ClickOnIt();
        }
        public void ClickCart()
        {
            ElementHelper.WaitByXPath(cartPath);
            cartLink= driver.FindElement(By.XPath(cartPath));
            cartLink.ClickOnIt();
        }
        public void ClickSignOut()
        {
            signOutLink.ClickOnIt();
        }
    }
}