﻿using AutoFramework.HelperClasses;
using AutoFramework.SetUp;
using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestProject.PageObjects
{
    public class LoginPage
    {
        public IWebDriver driver = Browsers.GetDriver;

        [FindsBy(How = How.XPath, Using = "//*[@id='email']")]
        [CacheLookup]
        private IWebElement Email;
        [FindsBy(How = How.XPath, Using = "//*[@id='passwd']")]
        [CacheLookup]
        private IWebElement Password;
        [FindsBy(How = How.XPath, Using = "//*[@id='SubmitLogin']")]
        [CacheLookup]
        private IWebElement btnLogin;
        //Create account
        [FindsBy(How = How.XPath, Using = "//*[@id='email_create']")]
        [CacheLookup]
        private IWebElement accountEmail;
        [FindsBy(How = How.XPath, Using = "//*[@id='SubmitCreate']")]
        [CacheLookup]
        private IWebElement btnCreate;

        //string to store element identifiers
        string alert = "//*[@id='center_column']/div[1]/ol/li/text()";

        public void ToLogin(int i)
        {
            string[] row1 = { "<div style='color: black; font-size: 20px; font-weight: bold'>Expected Result</div>", "<div style='color: black; font-weight: bold; font-size: 20px'>Actual Result </div>" };
            string[] row2 = { "<div style='color: grey; font-weight: bold'>User should log in with the entered credentials</div>", "<div style='color: green; font-weight: bold'>User logged in as the user into the application successfully</div>" };
            string[] row3 = { "<div style='color: grey; font-weight: bold'>User should log in with the entered credentials</div>", "<div style='color: red; font-weight: bold'>User is not logged in</div>" };
            string[][] passdata = new string[2][] { row1, row2 };
            string[][] faildata = new string[2][] { row1, row3 };
            string secondstep = "Click on Sign In Link";
            string thirdstep = "Enter username and password of the registered user";
            string fourthstep = "Click on SignIn button";
            try
            {
                ReportHelper.CreateNode("<h5>Scenario : SignIn to the Application</h5>");
                ExcelHelper.PopulateInCollection("Login");
                string email = ExcelHelper.ReadData(i, "Username");
                string password = ExcelHelper.ReadData(i, "Password");
                Email.EnterText(email);
                Password.EnterText(password);
                ReportHelper.TakeFullPageScreenshot("LoginPage_");
                btnLogin.ClickOnIt();
                if (driver.Url.Contains("http://automationpractice.com/index.php?controller=my-account"))
                {
                    ReportHelper.PassTest(secondstep);
                    ReportHelper.PassTest(thirdstep);
                    ReportHelper.PassTest(fourthstep);
                    ReportHelper.LogTest(Status.Pass, passdata);
                    ReportHelper.TakeFullPageScreenshot("LoginPage_Pass");

                }
                else
                {
                    ReportHelper.LogInfo(secondstep);
                    ReportHelper.LogInfo(thirdstep);
                    ReportHelper.LogInfo(fourthstep);
                    ReportHelper.LogTest(Status.Fail, faildata);
                    ReportHelper.TakeFullPageScreenshot("LoginPage_");
                    if (driver.FindElements(By.XPath("//*[@id='center_column']/div[1]/ol/li[contains(text(), 'Authentication failed.')]")).Count != 0)
                    {
                        ReportHelper.FailTest("Sign Up first if not registered!!!");
                    }
                }
            }
            catch (Exception ex)
            {
                ReportHelper.TestError(ex);
                ReportHelper.TakeFullPageScreenshot("LoginPage_exception_");
            }

        }

        public void ClickCreateAccount(int i)
        {
            string firststep = "A new user should first signup";
            string secondstep = "Click on Sign In link and Enter email id for which the account is to created in the Login page";
            string thirdstep = "Click on Create account button";
            try
            {
                ReportHelper.CreateNode("<h5>Scenario : Enter EmailId to create new account</h5>");
                ExcelHelper.PopulateInCollection("CreateAccount");
                string email = ExcelHelper.ReadData(i, "EmailId");
                accountEmail.EnterText(email);
                btnCreate.ClickOnIt();
                ElementHelper.ThreadWait(3000);
                if (driver.Url.Contains("http://automationpractice.com/index.php?controller=authentication"))
                {

                    ReportHelper.PassTest(firststep);
                    ReportHelper.PassTest(secondstep);
                    ReportHelper.PassTest(thirdstep);
                    ReportHelper.PassTest("User is successfully navigated to create account page");
                    ReportHelper.TakeFullPageScreenshot("clickaccount_");

                }
                else
                {
                    ReportHelper.LogInfo(firststep);
                    ReportHelper.LogInfo(secondstep);
                    ReportHelper.LogInfo(thirdstep);
                    ReportHelper.FailTest("User is not navigated to create account page");
                    ReportHelper.TakeFullPageScreenshot("clickaccount_");
                }
            }
            catch (Exception ex)
            {
                ReportHelper.TestError(ex);
                ReportHelper.TakeFullPageScreenshot("clickaccount_exception_");
            }

        }
    }
}
