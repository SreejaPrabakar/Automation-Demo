﻿using AutoFramework.HelperClasses;
using AutoFramework.SetUp;
using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestProject.PageObjects
{
    public class CreateAccountPage
    {
        public IWebDriver driver = Browsers.GetDriver;

        [FindsBy(How = How.Id, Using = "customer_firstname")]
        [CacheLookup]
        private IWebElement FirstName;
        [FindsBy(How = How.XPath, Using = "//*[@id='customer_lastname']")]
        [CacheLookup]
        private IWebElement LastName;
        [FindsBy(How = How.XPath, Using = "//*[@id='passwd']")]
        [CacheLookup]
        private IWebElement Password;
        [FindsBy(How = How.XPath, Using = "//*[@id='days']")]
        [CacheLookup]
        private IWebElement Days;
        [FindsBy(How = How.XPath, Using = "//*[@id='months']")]
        [CacheLookup]
        private IWebElement Months;
        [FindsBy(How = How.XPath, Using = "//*[@id='years']")]
        [CacheLookup]
        private IWebElement Years;
        [FindsBy(How = How.XPath, Using = "//*[@id='firstname']")]
        [CacheLookup]
        private IWebElement Fname;
        [FindsBy(How = How.XPath, Using = "//*[@id='lastname']")]
        [CacheLookup]
        private IWebElement Lname;
        [FindsBy(How = How.XPath, Using = "//*[@id='address1']")]
        [CacheLookup]
        private IWebElement Addr;
        [FindsBy(How = How.XPath, Using = "//*[@id='city']")]
        [CacheLookup]
        private IWebElement City;
        [FindsBy(How = How.XPath, Using = "//*[@id='id_state']")]
        [CacheLookup]
        private IWebElement State;
        [FindsBy(How = How.XPath, Using = "//*[@id='postcode']")]
        [CacheLookup]
        private IWebElement Zipcode;
        [FindsBy(How = How.XPath, Using = "//*[@id='phone_mobile']")]
        [CacheLookup]
        private IWebElement Phone;
        [FindsBy(How = How.XPath, Using = "//*[@id='phone']")]
        [CacheLookup]
        private IWebElement HomePhone;
        [FindsBy(How = How.Id, Using = "other")]
        [CacheLookup]
        private IWebElement Others;
        [FindsBy(How = How.XPath, Using = "//*[@id='submitAccount']")]
        [CacheLookup]
        private IWebElement btnregister;

        // string to store element identifiers
        string pwd_path = "//*[@id='passwd']";
        public void SendDOB()
        {
            Days.SelectByText("10  ");
            Months.SelectByText("March ");
            Years.SelectByText("2002  ");
        }
        public void ToCreateAccount(int i)
        {
            string[] row1 = { "<div style='color: black; font-size: 20px; font-weight: bold'>Expected Result</div>", "<div style='color: black; font-weight: bold; font-size: 20px'>Actual Result </div>" };
            string[] row2 = { "<div style='color: grey; font-weight: bold'>Account should be created with entered information</div>", "<div style='color: green; font-weight: bold'>Account is created for new user</div>" };
            string[] row3 = { "<div style='color: grey; font-weight: bold'>Account should be created with entered information</div>", "<div style='color: red; font-weight: bold'>Account is not created</div>" };
            string[][] passdata = new string[2][] { row1, row2 };
            string[][] faildata = new string[2][] { row1, row3 };
            string firststep = "Enter all mandatory fields in create account page";
            string secondstep = "Select DOB, State";
            string thirdstep = "Click on Register button";
            try
            {
                ReportHelper.CreateNode("<h5>Scenario : Create account for new user registration</h5>");
                ExcelHelper.PopulateInCollection("CreateAccount");
                string email = ExcelHelper.ReadData(i, "EmailId");
                string firstname = ExcelHelper.ReadData(i, "FirstName");
                string lastname = ExcelHelper.ReadData(i, "LastName");
                string pwd = ExcelHelper.ReadData(i, "Password");
                string address = ExcelHelper.ReadData(i, "Address");
                string city = ExcelHelper.ReadData(i, "City");
                string zipcode = ExcelHelper.ReadData(i, "Zipcode");
                string phoneno = ExcelHelper.ReadData(i, "PhoneNo");
                address = address + ElementHelper.RandomString(4,true);
                FirstName.EnterText(firstname);
                LastName.EnterText(lastname);
                ElementHelper.WaitByXPath(pwd_path);
                Password.EnterText(pwd);
                SendDOB();
                Addr.EnterText(address);
                City.EnterText(city);
                State.SelectByIndex(1);
                string state = State.GetSelectedValue();
                Zipcode.EnterText(zipcode);
                Others.EnterText("67890123");
                Phone.EnterText(phoneno);
                HomePhone.EnterText("04456785678");
                ReportHelper.TakeFullPageScreenshot("createaccount_");
                btnregister.ClickOnIt();
                if (driver.Url.Contains("http://automationpractice.com/index.php?controller=my-account"))
                {

                    ReportHelper.PassTest(firststep);
                    ReportHelper.PassTest(secondstep);
                    ReportHelper.PassTest(thirdstep);
                    ReportHelper.LogTest(Status.Pass, passdata);
                    ReportHelper.LogInfo("State selected while creating account: " + state);
                    ReportHelper.TakeFullPageScreenshot("createaccount_");

                }
                else
                {

                    ReportHelper.LogInfo(firststep);
                    ReportHelper.LogInfo(secondstep);
                    ReportHelper.LogInfo(thirdstep);
                    ReportHelper.LogTest(Status.Fail, faildata);
                    ReportHelper.TakeFullPageScreenshot("createaccount_fail");

                }
            }
            catch (Exception ex)
            {
                ReportHelper.TestError(ex);
                ReportHelper.TakeFullPageScreenshot("createaccount_exception_");
            }

        }
    }
}