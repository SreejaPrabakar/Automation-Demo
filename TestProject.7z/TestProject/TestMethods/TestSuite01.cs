﻿using AutoFramework.HelperClasses;
using AutoFramework.SetUp;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TestProject.PageObjects;

namespace TestProject.TestMethods
{
    [TestFixture]
    public class TestSuite01 : AutomationCore
    {
        [Test]
        public void TC01()
        {
            ReportHelper.CreateTest("TC01", "<h4>Testcase_1</h4>");
            ExcelHelper.ExcelToDataTable();
            PageEntry.MyStore.ClickSignIn();
            PageEntry.Login.ClickCreateAccount(1);
            PageEntry.CreateAccount.ToCreateAccount(1);
            PageEntry.MyStore.ClickSignOut();
            PageEntry.MyStore.ClickSignIn();
            PageEntry.Login.ToLogin(1);
            PageEntry.MyStore.ClickSignOut();
        }
    }
}